var resx = {
	tile_service: (location.protocol.indexOf('http') == 0 ? location.protocol : 'http:') + '//api.mapmyindia.com/wm2/map-nt-india',
	geocoder_service: (location.protocol.indexOf('http') == 0 ? location.protocol : 'http:') + '//api.mapmyindia.com/wm2/map-nt-india?',
	route_service: (location.protocol.indexOf('http') == 0 ? location.protocol : 'http:') + '//api.mapmyindia.com/wm2/map-nt-india?',
	load_service: (location.protocol.indexOf('http') == 0 ? location.protocol : 'http:') + '//api.mapmyindia.com/wm2/api',
	max_ssf: 1,
	
	map_defs: {
		"bounds":{"x1":49029632,"y1":4433920,"x2":72777728,"y2":29816832},
		"zf_base":2,
		"min_zl":2,
		"max_zl":15,
		"default_center":{"x":60903680,"y":17125376},
		"default_zl":15,
		"copyright": "� 2005-2015 Mireo, MapmyIndia",
		"back_color": "#A5D3F1"
	}
};


resx.tile_service = resx.tile_service.concat("/1460313000?");var srcs = ["/1439211254?fun=load_logo&scope=nt-india&v=0.8","/1449672325?fun=load_adv&v=0.8&lang=&excl_imgs=0","/1459846838?fun=load_mapjs&v=0.8&excl_imgs=0"]
var wm_auth_key = '53873984';


var loadJS = function(source) {
   if (!source) return;
   document.write('<script src="' + source + '"></script>');
};
(function() {
   for(var i = 0; i < srcs.length; ++i) {
       loadJS(resx.load_service + srcs[i]);
   }
})();