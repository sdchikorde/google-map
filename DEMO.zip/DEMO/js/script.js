var app = angular.module("plunker", []).
config(function($routeProvider, $locationProvider, $httpProvider) {

    $routeProvider.when('/home', {
        templateUrl: 'home.html',
        controller: 'HomeCtrl'
    });
    $routeProvider.when('/about', {
        templateUrl: 'about.html',
        controller: 'AboutCtrl'
    });
    $routeProvider.when('/contact', {
        templateUrl: 'contact.html',
        controller: 'ContactCtrl'
    });
    $routeProvider.otherwise({
        redirectTo: '/home',
        controller: 'HomeCtrl',
    });
});

app.controller('NavCtrl', ['$scope', '$location', '$http', function($scope, $location, $http, $templateCache) {

    $scope.navClass = function(page) {
        var currentRoute = $location.path().substring(1) || 'home';
        return page === currentRoute ? 'active' : '';
    };
    $scope.getDir = function()
    {
        get_route_result();
    }
    $scope.view = 'map';
    $scope.isMapActive = function(type) {
        if (type == $scope.view)
            return 'active';
    }
    $scope.isSearchActive = function(type) {
        if (type == $scope.view)
            return 'active';
    }
    $scope.isDirectionActive = function(type) {
        if (type == $scope.view)
            return 'active';
    }

    $scope.loadHome = function() {
        $location.url('/home');
    };

    $scope.loadAbout = function() {
        $location.url('/about');
    };

    $scope.loadContact = function() {
        $location.url('/contact');
    };

    $scope.searchq = '';
    $scope.searchresult = [];
    $scope.createmarker = function(lat, lng, tit) {
        removeMarker();
        var icon = mireo.stock_pins.pin_circle_red();
        var postion = new mireo.wgs.point(lat, lng);
        var title = tit;
        var mk = addMarker(postion, icon, title, false);
        wm.set_center_and_zoom(mk.position(), 8);
        $scope.searchq = '';
        $scope.searchresult = [];
        $scope.view = "map";
    }


    $scope.searchexec = function() {
        if ($scope.searchq != '' && $scope.searchq != undefined) {
            $scope.url = "https://api.mapmyindia.com/v3?fun=geocode&lic_key=qbcdmeykhhhmrzwnx7c6iwqqu2x7bqid&q=" + $scope.searchq + "&callback=JSON_CALLBACK";
            $http.jsonp($scope.url)
                .success(function(data, status, headers, config) {
                    $scope.searchresult = data;
                })
                .error(function(data, status, headers, config) {
                    alert("Request Failed");
                });

            /*$http.jsonp(url).then(function(status) {
    //your code when success
        alert('jhi');
        $scope.searchresult=status;
        console.log(status);
});*/


        } else {
            alert("Please type location to be searched.");
        }
    }


}]);

app.controller('AboutCtrl', function($scope, $compile) {
    console.log('inside about controller');

});

app.controller('HomeCtrl', function($scope, $compile) {
    console.log('inside home controller');

});

app.controller('ContactCtrl', function($scope, $compile) {
    console.log('inside contact controller');

});